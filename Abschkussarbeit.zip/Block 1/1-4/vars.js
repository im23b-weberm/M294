let name = "Test"
let age = 23

var test = "asdasd"

const test2 = 2;
